---
title: "Videos"
permalink: /pages/videos/
layout: splash
excerpt: "Videos HippoC"
sitemap: false
---
<style>
  body{
    margin: 0;
    padding: 0;
  }
  .wrapper{
    width: 100%;
    margin: 0 auto;
  }
  .header {
    height: 60px;
    background-color: white;
}
.contentwrap {
    background-color: white
}
.contentwrap:after {
    content: ".";
    display: block;
    clear: both;
    visibility: hidden;
    line-height: 0;
    height: 0;
}
.navArea {
    float: left;
    width: 25%;
    background-color: white;
    margin: 0 0 0 0;
    padding: 0;
}
.contentArea {
    float: right;
     width: 70%;
    background-color: white;
    margin: 0;
    padding: 0;
}
.footer {
    background-color: white;
    height: 20px;
    clear: both;
}
 .video-container {
  clear:left;
  position:relative;
	padding-bottom:56.25%;
	padding-top:1px;
	height:0;
  overflow:hidden;
  }
  
  .video-container iframe, div.video-container object, div.video-container embed {
	position:absolute;
  float:right;
  top:0;
	right:0;
	width:100%;
	height:100%;
} 

hr {
  background-color:#000000;
  color:#000000;
  border:#000000;
  height:1px;
}

</style>

<p align="center">Videos</p>
<p line-height="3em"> </p>
<div class="wrapper">
  <header class="header"><hr></header>
    <section class="contentwrap">
      <nav class="navArea">Underwater Hydrobatics with HippoCampus @ICRA2018</nav>
      <article class="contentArea">
      <div class="video-container">
      <iframe width="560" height="315" src="https://www.youtube.com/embed/BKLaj87kNZY" frameborder="0" allowfullscreen></iframe>
    </div>
      </article>
    </section>
  <!--  <div class="footer"><p style="font-size: 0.5px;"><br></p><hr></div> -->
</div>

<br>
<div class="wrapper">
  <header class="header"><hr><br></header>
    <section class="contentwrap">
    <nav class="navArea"><ul>Birth of HippoCampus</ul></nav>
      <article class="contentArea">
      <div class="video-container">
      <iframe width="560" height="315" src="https://www.youtube.com/embed/1y6KvrMqoo0" frameborder="0" allowfullscreen></iframe>
    </div>
      </article>
    </section>
   <!-- <div class="footer"><p style="font-size: 0.5px;"><br></p><hr></div> -->
</div>

<br>

<div class="wrapper">
  <header class="header"><hr></header>
    <section class="contentwrap">
      <nav class="navArea">Featured by IEEE Spectrum as one of the highlighted IROS15 videos</nav>
      <article class="contentArea">
      <div class="video-container">
      <iframe width="560" height="315" src="https://www.youtube.com/embed/9-VLE_Jn3u4" frameborder="0" allowfullscreen></iframe>
    </div>
      </article>
    </section>
  <!--  <div class="footer"><p style="font-size: 0.5px;"><br></p><hr></div> -->
</div>

<br>
<div class="wrapper">
  <header class="header"><hr></header>
    <section class="contentwrap">
      <nav class="navArea">Acoustic localization for µAUVs (ICRA16)</nav>
      <article class="contentArea">
      <div class="video-container">
      <iframe width="560" height="315" src="https://www.youtube.com/embed/5GqnwYsQp0M" frameborder="0" allowfullscreen></iframe>
    </div>
      </article>
    </section>
  <!--  <div class="footer"><p style="font-size: 0.5px;"><br></p><hr></div> -->
</div>

<br>
<div class="wrapper">
 <header class="header"><hr></header> 
    <section class="contentwrap">
      <nav class="navArea">HippoCampus µAUV 2.0</nav>
      <article class="contentArea">
      <div class="video-container">
      <iframe width="560" height="315" src="https://www.youtube.com/embed/PrH_exw1WXw" frameborder="0" allowfullscreen></iframe>
    </div>
      </article>
    </section>
    <!-- <div class="footer"><p style="font-size: 0.5px;"><br></p><hr></div> -->
</div>

<br>
<div class="wrapper">
 <header class="header"><hr></header> 
</div>
