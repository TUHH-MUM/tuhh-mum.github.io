---
title: "Contact"
permalink: /pages/contact/
layout: splash
excerpt: "Contact"
sitemap: false
---

<div style="margin-left:10%; margin-right:10%; text-align: justify">
<h1>Contact</h1>
</div>

The HippoCampus project is led by Eugen Solowjow, Daniel Dücker, Axel Hackbarth, and Prof. Edwin Kreuzer of the Institute of Mechanics and Ocean Engineering, Hamburg University of Technology.

The project is supported by Deutsche Forschungsgemeinschaft (DFG) and Wissenschaft im Dialog (WiD). The support is greatly acknowledged.

Email: HippoCAUV@gmail.com
