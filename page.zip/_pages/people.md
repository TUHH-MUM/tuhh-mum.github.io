---
title: "People"
permalink: /pages/people/
layout: splash
excerpt: "People"
sitemap: false
---

<style>
body{
  margin: 0;
  padding: 0;
}

 .box1, .box2, .box3 {
     float: left;
     width: 32%;
     margin-right: 2%;
     padding: 20px;
     background: #FFFFFF;
     box-sizing: border-box;
}

.box3 {
     margin-right: 0;
}
</style>

<h2>Team</h2>
{: .text-center}

<div style="margin-left:10%; margin-right:10%; text-align: justify">
  <div class="box1"><img src="https://johtobi.github.io/images/placeholder-male.jpg"><br><p style="font-size:80%">Eugen Solowjow</p></div>
  <div class="box2"><img src="https://johtobi.github.io/images/placeholder-male.jpg"><br><p style="font-size:80%">Daniel Dücker</p></div>
  <div class="box3"><img src="https://johtobi.github.io/images/placeholder-male.jpg"><br><p style="font-size:80%">Axel Hackbarth</p></div>
</div>
<br>
<div style="margin-left:10%; margin-right:10%; text-align: justify">
  <div class="box1"><img src="https://johtobi.github.io/images/placeholder-male.jpg"><br><p style="font-size:80%">Viktor Rausch</p></div>
  <div class="box2"><img src="https://johtobi.github.io/images/placeholder-male.jpg"><br><p style="font-size:80%">René Geist</p></div>
  <div class="box3"><img src="https://johtobi.github.io/images/placeholder-male.jpg"><br><p style="font-size:80%">Tobias Johannink</p></div>
  <!-- <div class="box3"><img src="https://johtobi.github.io/images/placeholder-male.jpg"><br><p style="font-size:80%">Max Mustermann</p></div> -->
</div>
