---
title: "HippoCampus"
permalink: /
layout: splash
excerpt: "HippoC"
sitemap: false
header:
  image: HippoC_Foto.jpg
---
<h1>HippoCampus - Micro Underwater Robot</h1>
{: .text-center}

<div style="margin-left:10%; margin-right:10%; text-align: center">
HippoCampus is a micro underwater robotic platform. It is intended for autonomous environmental exploration and monitoring. This project aims to be fully open-source. You can find detailed instructions for building your own HippoCampus on this website.
</div>


